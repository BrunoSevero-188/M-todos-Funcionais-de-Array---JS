const contas = [
  {
    descricao: "Aluguel",
    valor: 1200.00,
    pago: true
  },
  {
    descricao: "Conta de luz",
    valor: 250.75,
    pago: false
  },
  {
    descricao: "Internet",
    valor: 99.90,
    pago: true
  },
  {
    descricao: "Supermercado",
    valor: 480.30,
    pago: false
  },
  {
    descricao: "Plano de saúde",
    valor: 320.00,
    pago: true
  },
  {
    descricao: "Gasolina",
    valor: 350.00,
    pago: false
  },
  {
    descricao: "Academia",
    valor: 89.90,
    pago: true
  },
  {
    descricao: "Streaming (Netflix)",
    valor: 39.90,
    pago: true
  },
  {
    descricao: "Manutenção do carro",
    valor: 780.00,
    pago: false
  },
  {
    descricao: "Farmácia",
    valor: 120.45,
    pago: true
  },
  {
    descricao: "Escola das crianças",
    valor: 950.00,
    pago: false
  }
];

contas.forEach(conta => {
  console.log(`A conta ${conta.descricao} tem o valor de R$${conta.valor}`);
});

let total = 0;
contas.forEach(conta => total += conta.valor);
console.log("Total de todas as contas: R$", total.toFixed(2));

let descricoes = contas.map(conta => conta.descricao);
console.log("Descrição:",descricoes);

let valoresComJuros = contas.map(conta => conta.valor * 1.1);
console.log("Valores com Juros:",valoresComJuros);

let informacoes = contas.map(conta => `Descrição: ${conta.descricao} - Pago: ${conta.pago}`);
console.log("Informações:", informacoes);

let contasPagas = contas.filter(conta => conta.pago);
console.log("Contas pagas:", contasPagas);

let acimaDe500 = contas.filter(conta => conta.valor > 500);
console.log("Contas acima de 500:", acimaDe500);

let naoPagasAcima300 = contas.filter(conta => !conta.pago && conta.valor > 300);
console.log("Contas não pagas acima de 300:", naoPagasAcima300);

let totalContas = contas.reduce((acum, conta) => acum + conta.valor, 0);
console.log("Total geral:", totalContas);

let totalPagas = contas
  .filter(conta => conta.pago)
  .reduce((acum, conta) => acum + conta.valor, 0);
console.log("Total das contas pagas:", totalPagas);

let totalNaoPagas = contas
  .filter(conta => !conta.pago)
  .reduce((acum, conta) => acum + conta.valor, 0);
console.log("Total das contas não pagas:", totalNaoPagas);

let existeNaoPaga = contas.some(conta => !conta.pago);
console.log("Existe conta não paga?", existeNaoPaga);

let existeAcima1000 = contas.some(conta => conta.valor > 1000);
console.log("Existe conta acima de R$1000?", existeAcima1000);

let todasPagas = contas.every(conta => conta.pago);
console.log("Todas pagas?", todasPagas);

let todasAcima50 = contas.every(conta => conta.valor > 50);
console.log("Todas acima de 50?", todasAcima50);